/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primera.serie;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class PrimeraSerie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String Nombre = "Amilcar Josué Corleto Orozco";
        String Grado = "5to Baco A";
        
        System.out.println("Mi Nombre es "+Nombre+" y curso el grado de "+Grado);
        
        
        
        
// TODO code application logic here
    }
    
}
